package com.student.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.dao.Student;
import com.student.error.GlobalException;
import com.student.repository.StudentRepository;


@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepository studentRepository;
	@Override
	public Student saveStudent(@Valid Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}
	@Override
	public List<Student> getAllStudent() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}
	@Override
	public Student getStudentById(Integer studentid) throws GlobalException {
		// TODO Auto-generated method stub
		Optional<Student> st=studentRepository.findById(studentid);
		if(!st.isPresent()) {
			throw new GlobalException(studentid +" is not present");
		}else {
			return studentRepository.findById(studentid).get();
			}
	}
	@Override
	public void deleteById(Integer studentid) throws GlobalException {
		Optional<Student>st=studentRepository.findById(studentid);
		if(!st.isPresent()) {
			throw new GlobalException(studentid +" is not present");
		}else {
			 studentRepository.deleteById(studentid);
		}
	}
	@Override
	public Student updateStudentById(Student student, Integer studentid) throws GlobalException {
		Optional<Student>st= studentRepository.findById(studentid);
		if(!st.isPresent()) {
			throw new GlobalException(studentid +" is not present");
		}else {
		Student st1=studentRepository.findById(studentid).get();
		if(st1!=null) {
			st1.setStudentname(student.getStudentname());
			st1.setStudentage(student.getStudentage());
			st1.setStudentfee(student.getStudentfee());
			st1.setStudentdept(student.getStudentdept());
			return studentRepository.save(st1);
		}
		return st1;
	}
	}
}
