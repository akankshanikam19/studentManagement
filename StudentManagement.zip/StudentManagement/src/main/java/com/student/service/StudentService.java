package com.student.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.student.dao.Student;
import com.student.error.GlobalException;

@Service
public interface StudentService {

	public Student saveStudent(@Valid Student student);

	public List<Student> getAllStudent();

	public Student getStudentById(Integer studentid) throws GlobalException;

	public void deleteById(Integer studentid) throws GlobalException;

	public Student updateStudentById(Student student, Integer studentid) throws GlobalException;

}
