package com.student.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.dao.Student;
import com.student.error.GlobalException;
import com.student.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@PostMapping("/saveStudent")
	public ResponseEntity<Student> saveStudent(@Valid @RequestBody Student student) {
		Student st= studentService.saveStudent(student);
		return new ResponseEntity<Student>(st,HttpStatus.CREATED);	
	}
	
	@GetMapping("/getAllStudent")
	public List<Student> getAllStudent(){
		return studentService.getAllStudent();
		
	}
	@GetMapping("/getStudentById/{sid}")
	public Student getStudentById(@PathVariable("sid") Integer studentid) throws GlobalException {
		return studentService.getStudentById(studentid);
		
	}
	@DeleteMapping("/deleteById/{sid}")
	public String deleteById(@PathVariable("sid") Integer studentid) throws GlobalException {
		studentService.deleteById(studentid);
		return studentid+" is deleted";
	}
	@PutMapping("/updateStudentById/{sid}")
	public Student updateStudentById(@RequestBody Student student,@PathVariable("sid") Integer studentid) throws GlobalException{
		return studentService.updateStudentById(student,studentid);
		
	}
}
