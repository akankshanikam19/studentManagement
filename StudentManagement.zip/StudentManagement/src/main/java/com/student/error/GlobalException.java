package com.student.error;

public class GlobalException extends Exception{

	public GlobalException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
	
}
