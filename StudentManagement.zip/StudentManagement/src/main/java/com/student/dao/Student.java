package com.student.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
private Integer studentid;
  
private String studentname;
    
private int studentage;  

private float studentfee;
	
private String studentdept;

public Student() {
	super();
	// TODO Auto-generated constructor stub
}

public Student(String studentname, int studentage, float studentfee, String studentdept) {
	super();
	this.studentname = studentname;
	this.studentage = studentage;
	this.studentfee = studentfee;
	this.studentdept = studentdept;
}

public Integer getStudentid() {
	return studentid;
}

public void setStudentid(Integer studentid) {
	this.studentid = studentid;
}

public String getStudentname() {
	return studentname;
}

public void setStudentname(String studentname) {
	this.studentname = studentname;
}

public int getStudentage() {
	return studentage;
}

public void setStudentage(int studentage) {
	this.studentage = studentage;
}

public float getStudentfee() {
	return studentfee;
}

public void setStudentfee(float studentfee) {
	this.studentfee = studentfee;
}

public String getStudentdept() {
	return studentdept;
}

public void setStudentdept(String studentdept) {
	this.studentdept = studentdept;
}

@Override
public String toString() {
	return "Student [studentid=" + studentid + ", studentname=" + studentname + ", studentage=" + studentage
			+ ", studentfee=" + studentfee + ", studentdept=" + studentdept + "]";
}
 

}
